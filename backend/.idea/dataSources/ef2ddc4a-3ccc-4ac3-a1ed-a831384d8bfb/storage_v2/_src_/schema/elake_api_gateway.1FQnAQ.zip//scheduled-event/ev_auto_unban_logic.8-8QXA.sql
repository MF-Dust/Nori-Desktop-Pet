create definer = root@localhost event ev_auto_unban_logic on schedule
	every '30' SECOND
		starts '2026-07-30 00:27:36'
	on completion preserve
	enable
	comment '自动清理过期封禁'
	do
	BEGIN
		-- 仅解封状态为 2 (临时封禁) 且时间已过期的记录
		UPDATE `api_keys`
		SET `banned`       = 0,
			`banned_start` = NULL,
			`banned_end`   = NULL
		WHERE `banned` = 2
		  AND `banned_end` IS NOT NULL
		  AND `banned_end` < NOW();
	END;

