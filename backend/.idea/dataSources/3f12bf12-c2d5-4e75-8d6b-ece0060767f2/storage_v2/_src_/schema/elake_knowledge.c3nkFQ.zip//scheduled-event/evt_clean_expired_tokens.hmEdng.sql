create definer = root@localhost event evt_clean_expired_tokens on schedule
	every '1' DAY
		starts '2026-08-01 15:01:16'
	enable
	comment '每天清理过期的刷新令牌'
	do
	DELETE FROM refresh_tokens WHERE expires_at < NOW();

